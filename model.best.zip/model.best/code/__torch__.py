class ModelWrapper(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  classes : List[str]
  size : Tuple[int, int]
  thresholds : Tuple[float, float, float, float, float, float, float, float, float, float, float, float, float, float, float, float, float]
  model : __torch__.timm.models.resnet.ResNet
  def forward(self: __torch__.ModelWrapper,
    image: Tensor) -> Tensor:
    _0 = torch.sigmoid((self.model).forward(image, ))
    return _0
