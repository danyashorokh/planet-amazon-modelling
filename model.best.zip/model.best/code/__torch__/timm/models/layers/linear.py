class Linear(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  _is_full_backward_hook : NoneType
  in_features : Final[int] = 512
  out_features : Final[int] = 17
  def forward(self: __torch__.timm.models.layers.linear.Linear,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.linear
    bias = torch.to(self.bias, ops.prim.dtype(input))
    _1 = torch.to(self.weight, ops.prim.dtype(input))
    return _0(input, _1, bias, )
