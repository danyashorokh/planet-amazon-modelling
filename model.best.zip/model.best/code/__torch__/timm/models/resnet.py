class ResNet(Module):
  __parameters__ = []
  __buffers__ = []
  num_classes : int
  drop_rate : float
  training : bool
  _is_full_backward_hook : Optional[bool]
  num_features : int
  conv1 : __torch__.torch.nn.modules.conv.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  act1 : __torch__.torch.nn.modules.activation.ReLU
  maxpool : __torch__.torch.nn.modules.pooling.MaxPool2d
  layer1 : __torch__.torch.nn.modules.container.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_8.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_16.Sequential
  layer4 : __torch__.torch.nn.modules.container.___torch_mangle_24.Sequential
  global_pool : __torch__.timm.models.layers.adaptive_avgmax_pool.SelectAdaptivePool2d
  fc : __torch__.timm.models.layers.linear.Linear
  def forward(self: __torch__.timm.models.resnet.ResNet,
    x: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.dropout
    x0 = (self).forward_features(x, )
    x1 = (self.global_pool).forward(x0, )
    if bool(self.drop_rate):
      x3 = _0(x1, self.drop_rate, self.training, False, )
      x2 = x3
    else:
      x2 = x1
    return (self.fc).forward(x2, )
  def forward_features(self: __torch__.timm.models.resnet.ResNet,
    x: Tensor) -> Tensor:
    x4 = (self.conv1).forward(x, )
    x5 = (self.bn1).forward(x4, )
    x6 = (self.act1).forward(x5, )
    x7 = (self.maxpool).forward(x6, )
    x8 = (self.layer1).forward(x7, )
    x9 = (self.layer2).forward(x8, )
    x10 = (self.layer3).forward(x9, )
    return (self.layer4).forward(x10, )
class BasicBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  aa : NoneType
  se : NoneType
  downsample : NoneType
  stride : int
  dilation : int
  drop_block : NoneType
  drop_path : NoneType
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  act1 : __torch__.torch.nn.modules.activation.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  act2 : __torch__.torch.nn.modules.activation.ReLU
  def forward(self: __torch__.timm.models.resnet.BasicBlock,
    x: Tensor) -> Tensor:
    x11 = (self.conv1).forward(x, )
    x12 = (self.bn1).forward(x11, )
    x13 = (self.act1).forward(x12, )
    x14 = (self.conv2).forward(x13, )
    x15 = (self.bn2).forward(x14, )
    x16 = torch.add_(x15, x)
    return (self.act2).forward(x16, )
