class BasicBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  aa : NoneType
  se : NoneType
  downsample : NoneType
  stride : int
  dilation : int
  drop_block : NoneType
  drop_path : NoneType
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_11.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_10.BatchNorm2d
  act1 : __torch__.torch.nn.modules.activation.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_11.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_10.BatchNorm2d
  act2 : __torch__.torch.nn.modules.activation.ReLU
  def forward(self: __torch__.timm.models.resnet.___torch_mangle_15.BasicBlock,
    x: Tensor) -> Tensor:
    x0 = (self.conv1).forward(x, )
    x1 = (self.bn1).forward(x0, )
    x2 = (self.act1).forward(x1, )
    x3 = (self.conv2).forward(x2, )
    x4 = (self.bn2).forward(x3, )
    x5 = torch.add_(x4, x)
    return (self.act2).forward(x5, )
