class ModelWrapper(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  classes : List[str]
  size : Tuple[int, int]
  thresholds : Tuple[float, float, float, float, float, float, float, float, float, float, float, float, float, float, float, float, float]
  model : __torch__.ModelWrapper
  def forward(self: __torch__.___torch_mangle_183.ModelWrapper,
    image: Tensor) -> Tensor:
    model = self.model
    _0 = torch.sigmoid((model).forward(image, ))
    return _0
