class SelectAdaptivePool2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  pool_type : str
  flatten : __torch__.torch.nn.modules.flatten.Flatten
  pool : __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d
  def forward(self: __torch__.timm.models.layers.adaptive_avgmax_pool.SelectAdaptivePool2d,
    x: Tensor) -> Tensor:
    pool = self.pool
    x0 = (pool).forward(x, )
    flatten = self.flatten
    return (flatten).forward(x0, )
