class Linear(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  _is_full_backward_hook : NoneType
  out_features : Final[int] = 17
  in_features : Final[int] = 512
  def forward(self: __torch__.timm.models.layers.linear.Linear,
    input: Tensor) -> Tensor:
    bias = self.bias
    bias0 = torch.to(bias, ops.prim.dtype(input))
    weight = self.weight
    _0 = torch.to(weight, ops.prim.dtype(input))
    return torch.linear(input, _0, bias0)
