class ResNet(Module):
  __parameters__ = []
  __buffers__ = []
  num_classes : int
  drop_rate : float
  training : bool
  _is_full_backward_hook : Optional[bool]
  num_features : int
  conv1 : __torch__.torch.nn.modules.conv.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  act1 : __torch__.torch.nn.modules.activation.ReLU
  maxpool : __torch__.torch.nn.modules.pooling.MaxPool2d
  layer1 : __torch__.torch.nn.modules.container.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_8.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_16.Sequential
  layer4 : __torch__.torch.nn.modules.container.___torch_mangle_24.Sequential
  global_pool : __torch__.timm.models.layers.adaptive_avgmax_pool.SelectAdaptivePool2d
  fc : __torch__.timm.models.layers.linear.Linear
  def forward(self: __torch__.timm.models.resnet.ResNet,
    x: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.dropout
    x0 = (self).forward_features(x, )
    global_pool = self.global_pool
    x1 = (global_pool).forward(x0, )
    drop_rate = self.drop_rate
    if bool(drop_rate):
      drop_rate0 = self.drop_rate
      training = self.training
      x3 = _0(x1, drop_rate0, training, False, )
      x2 = x3
    else:
      x2 = x1
    fc = self.fc
    return (fc).forward(x2, )
  def forward_features(self: __torch__.timm.models.resnet.ResNet,
    x: Tensor) -> Tensor:
    conv1 = self.conv1
    x4 = (conv1).forward(x, )
    bn1 = self.bn1
    x5 = (bn1).forward(x4, )
    act1 = self.act1
    x6 = (act1).forward(x5, )
    maxpool = self.maxpool
    x7 = (maxpool).forward(x6, )
    layer1 = self.layer1
    x8 = (layer1).forward(x7, )
    layer2 = self.layer2
    x9 = (layer2).forward(x8, )
    layer3 = self.layer3
    x10 = (layer3).forward(x9, )
    layer4 = self.layer4
    return (layer4).forward(x10, )
class BasicBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  aa : NoneType
  se : NoneType
  downsample : NoneType
  stride : int
  dilation : int
  drop_block : NoneType
  drop_path : NoneType
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  act1 : __torch__.torch.nn.modules.activation.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  act2 : __torch__.torch.nn.modules.activation.ReLU
  def forward(self: __torch__.timm.models.resnet.BasicBlock,
    x: Tensor) -> Tensor:
    conv1 = self.conv1
    x11 = (conv1).forward(x, )
    bn1 = self.bn1
    x12 = (bn1).forward(x11, )
    act1 = self.act1
    x13 = (act1).forward(x12, )
    conv2 = self.conv2
    x14 = (conv2).forward(x13, )
    bn2 = self.bn2
    x15 = (bn2).forward(x14, )
    x16 = torch.add_(x15, x)
    act2 = self.act2
    return (act2).forward(x16, )
